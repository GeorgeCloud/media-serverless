"""Initialize Config class to access environment variables."""
class Config(object):
    """Set environment variables."""
    SECRET_KEY = "key"
